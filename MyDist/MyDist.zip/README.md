# -csc436_Fall2019_Ravi_HW2_MyDist
mydist - first angular project

https://github.com/rsharm18/csc436_Fall2019_Ravi_HW2_MyDist.git


Added the below as per teh HW instruction
1. Added an image
2. Added a like button
3. added a span element in mybutton with text as "Image is Liked == False". The boolean text is true/false based on the isLike flag.
	And When islike flag is true a green-bg color css is assigned to the like button.

4. Implemented the chat application
	created the message, user and messages model (as per spec)
	added a user ref in message
	created a service to to create the message data and assign it messages.
	
5. Extra credit - update app component as per the sped

=============================================================================

# MyDist

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 8.3.2.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
